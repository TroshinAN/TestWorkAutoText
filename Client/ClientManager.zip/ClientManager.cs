﻿using System;
using System.Linq;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Threading;

namespace Client
{
    internal class ClientManager1 : IDisposable
    {
        private readonly Socket _socket;
        private IPEndPoint _ipPoint;
        private IPHostEntry _ipHost;

        public bool Connected { get => _socket.Connected; }
        public string HostName { get => _ipHost.HostName; }
        public string IPAddress { get => _ipPoint.Address.ToString(); }
        public int Port { get => _ipPoint.Port; }
        public Action<string> Message { get; set; } = delegate { };

        private ManualResetEvent _resetEvent;

        public ClientManager1()
        {
            _socket = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
            _socket.ReceiveTimeout = 2000;
            _resetEvent = new ManualResetEvent(false);
        }

        public bool Connect(string address, int port)
        {
            if (string.IsNullOrWhiteSpace(address))
            {
                Message("Строка адреса не может быть пустой");
                return false;
            }

            try
            {
                _ipHost = Dns.GetHostEntry(address);
            }
            catch (Exception ex)
            {
                Message($"Не удалось определить адрес '{address}': {ex.Message}");
                return false;
            }

            var ipAddress = _ipHost.AddressList.Where(w => w.AddressFamily == AddressFamily.InterNetwork).FirstOrDefault();

            if (ipAddress == null)
            {
                Message($"Не удалось определить IP-адрес у хоста '{address}'");
                return false;
            }

            return Connect(ipAddress, port);
        }

        private bool Connect(IPAddress address, int port)
        {
            Close();
            _resetEvent.Reset();

            try
            {
                _ipPoint = new IPEndPoint(address, port);
                _socket.BeginConnect(_ipPoint, (state) =>
                    {
                        _resetEvent.Set();
                        var s = (Socket)state.AsyncState;
                        s.EndConnect(state);
                    }, _socket);

                _resetEvent.WaitOne();
            }
            catch (Exception ex)
            {
                Message($"Не удалось подключиться к серверу {HostName}: {ex.Message}");
                return false;
            }

            Message($"Установлено соединение с сервером {HostName}");
            return true;
        }

        public bool TranslateMessage(string message, out string result)
        {
            result = String.Empty;
            return (SendToServer(message) && ReceiveFromServer(ref result));
        }

        private bool SendToServer(string message)
        {
            try
            {
                var sendData = Encoding.UTF8.GetBytes(message);
                _socket.Send(sendData);
            }
            catch (Exception ex)
            {
                Message($"Ошибка передачи данных на сервер: {ex.Message}");
                return false;
            }

            return true;
        }

        private bool ReceiveFromServer(ref string result)
        {
            byte[] data;
            StringBuilder messageFromServer = new StringBuilder();

            do
            {
                int bytes = 0;
                data = new byte[255];

                try
                {
                    bytes = _socket.Receive(data, data.Length, SocketFlags.None);
                }
                catch (Exception ex)
                {
                    Message($"Ошибка приёма данных с сервера: {ex.Message}");
                    return false;
                }

                messageFromServer.Append(Encoding.UTF8.GetString(data, 0, bytes));

            } while (_socket.Available > 0);

            result = messageFromServer.ToString();

            return true;
        }

        public void Close()
        {
            if (Connected)
            {
                _socket.Disconnect(true);
            }
        }

        public void Dispose()
        {
            Close();
            _socket.Close();
        }
    }
}
